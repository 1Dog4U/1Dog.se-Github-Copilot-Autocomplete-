HI THERE!

My name is ELISE BJORKLUND-KNUUTILA

And I am the creator of this base for a virtual dog or/and pet game

In order to begin using this (this is a pre-built package):

Go to

register.php

and remove the :not()-tag from the css in that file (register.php), and then load the site in the browser, to test the game

